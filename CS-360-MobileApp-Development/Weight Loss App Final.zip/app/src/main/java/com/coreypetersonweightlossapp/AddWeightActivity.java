package com.coreypetersonweightlossapp;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Calendar;

public class AddWeightActivity extends AppCompatActivity {

    private EditText dateInput;
    private EditText weightInput;
    private Button saveWeightButton;
    private DatabaseHelper dbHelper;

    private static final int SMS_PERMISSION_CODE = 100;
    private final double GOAL_WEIGHT = 180.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        dbHelper = new DatabaseHelper(this);
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        saveWeightButton = findViewById(R.id.saveWeightButton);

        // 1. Prevent the keyboard from popping up on the date field
        dateInput.setFocusable(false);
        dateInput.setClickable(true);

        // 2. Launch the Calendar Dialog when the field is tapped
        dateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the current date to open the calendar to today
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        AddWeightActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                                // Android indexes months starting at 0 (January = 0), so we add 1
                                String formattedDate = (selectedMonth + 1) + "/" + selectedDay + "/" + selectedYear;
                                dateInput.setText(formattedDate);
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        // Save Button Logic
        saveWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = dateInput.getText().toString().trim();
                String weightStr = weightInput.getText().toString().trim();

                if (date.isEmpty() || weightStr.isEmpty()) {
                    Toast.makeText(AddWeightActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                double weight = Double.parseDouble(weightStr);

                boolean isInserted = dbHelper.addWeight(date, weight);
                if (isInserted) {
                    Toast.makeText(AddWeightActivity.this, "Weight Entry Saved", Toast.LENGTH_SHORT).show();

                    if (weight <= GOAL_WEIGHT) {
                        checkSmsPermissionAndSend();
                    } else {
                        finish();
                    }
                } else {
                    Toast.makeText(AddWeightActivity.this, "Failed to save entry", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void checkSmsPermissionAndSend() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendGoalReachedSms();
            finish();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendGoalReachedSms();
            } else {
                Toast.makeText(this, "SMS Permission Denied. Entry saved without notification.", Toast.LENGTH_LONG).show();
            }
            finish();
        }
    }

    private void sendGoalReachedSms() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("5554", null, "Congratulations! You reached your goal weight!", null, null);
            Toast.makeText(this, "Goal alert SMS sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}