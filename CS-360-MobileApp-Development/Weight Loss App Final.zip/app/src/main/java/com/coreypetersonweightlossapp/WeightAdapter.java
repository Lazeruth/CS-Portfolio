package com.coreypetersonweightlossapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<String> id_list, date_list, weight_list;
    private DatabaseHelper dbHelper;

    public WeightAdapter(Context context, ArrayList<String> id_list, ArrayList<String> date_list, ArrayList<String> weight_list) {
        this.context = context;
        this.id_list = id_list;
        this.date_list = date_list;
        this.weight_list = weight_list;
        dbHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflates row template XML
        View v = LayoutInflater.from(context).inflate(R.layout.weight_grid_row, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        // Populates the template with data
        holder.dateText.setText(date_list.get(position));
        holder.weightText.setText(weight_list.get(position));

        // Sets up the Delete action for this specific row
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1. Get the current, accurate position of this row the moment the button is clicked
                int currentPos = holder.getAdapterPosition();

                // 2. Safety check: prevents a crash if the user double-clicks delete while it's already animating away
                if (currentPos == RecyclerView.NO_POSITION) {
                    return;
                }

                // 3. Use currentPos instead of position
                int idToDelete = Integer.parseInt(id_list.get(currentPos));
                boolean deleted = dbHelper.deleteWeight(idToDelete);

                if (deleted) {
                    Toast.makeText(context, "Entry Deleted", Toast.LENGTH_SHORT).show();
                    // Remove from arrays and update the UI grid
                    id_list.remove(currentPos);
                    date_list.remove(currentPos);
                    weight_list.remove(currentPos);
                    notifyItemRemoved(currentPos);
                    notifyItemRangeChanged(currentPos, id_list.size());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return id_list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, weightText;
        Button deleteButton;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            dateText = itemView.findViewById(R.id.dateText);
            weightText = itemView.findViewById(R.id.weightText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
