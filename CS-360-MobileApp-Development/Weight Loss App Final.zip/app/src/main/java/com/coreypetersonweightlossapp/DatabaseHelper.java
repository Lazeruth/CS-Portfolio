package com.coreypetersonweightlossapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

/**
 * DatabaseHelper to manage database creation and version management.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Name and Version
    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table Names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHT = "weight_log";

    // Users Table Columns
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Weight Log Table Columns
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_WEIGHT_DATE = "date";
    public static final String COL_WEIGHT_VALUE = "weight";

    // SQL statement to create the Users table
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + " ("
            + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_USERNAME + " TEXT UNIQUE, "
            + COL_PASSWORD + " TEXT)";

    // SQL statement to create the Weight table
    private static final String CREATE_TABLE_WEIGHT = "CREATE TABLE " + TABLE_WEIGHT + " ("
            + COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COL_WEIGHT_DATE + " TEXT, "
            + COL_WEIGHT_VALUE + " REAL)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Execute SQL to create the persistent tables
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_WEIGHT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        // Create tables again
        onCreate(db);
    }

    /**
     * Inserts a new user into the database.
     * Returns true if successful, false if it fails (e.g., username already exists).
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        // insert() returns -1 if there is an error
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /**
     * Checks if the username and password match an existing database record.
     * Returns true if valid, false if invalid.
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COL_USER_ID };
        String selection = COL_USERNAME + "=? AND " + COL_PASSWORD + "=?";
        String[] selectionArgs = { username, password };

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();

        return count > 0;
    }

    /**
     * CREATE: Inserts a new daily weight entry.
     */
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_DATE, date);
        values.put(COL_WEIGHT_VALUE, weight);
        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;
    }

    /**
     * READ: Retrieves all weight entries to display in the grid.
     */
    public Cursor getWeightData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHT, null);
    }

    /**
     * UPDATE: Changes the values associated with a specific entry.
     */
    public boolean updateWeight(int id, String newDate, double newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_DATE, newDate);
        values.put(COL_WEIGHT_VALUE, newWeight);
        return db.update(TABLE_WEIGHT, values, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }

    /**
     * DELETE: Removes an individual entry from the database.
     */
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHT, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }
}
