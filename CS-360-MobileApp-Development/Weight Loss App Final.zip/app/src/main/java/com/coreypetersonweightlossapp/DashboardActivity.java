package com.coreypetersonweightlossapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button addWeightButton;
    private DatabaseHelper dbHelper;
    private ArrayList<String> idList, dateList, weightList;
    private WeightAdapter weightAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        recyclerView = findViewById(R.id.recyclerView);
        addWeightButton = findViewById(R.id.addWeightButton);

        dbHelper = new DatabaseHelper(this);
        idList = new ArrayList<>();
        dateList = new ArrayList<>();
        weightList = new ArrayList<>();

        storeDataInArrays();

        weightAdapter = new WeightAdapter(DashboardActivity.this, idList, dateList, weightList);
        recyclerView.setAdapter(weightAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(DashboardActivity.this));

        // Add weight button logic
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, AddWeightActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        idList.clear();
        dateList.clear();
        weightList.clear();
        storeDataInArrays();
        if (weightAdapter != null) {
            weightAdapter.notifyDataSetChanged();
        }
    }

    private void storeDataInArrays() {
        Cursor cursor = dbHelper.getWeightData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No data. Add your first weight entry!", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                idList.add(cursor.getString(0));
                dateList.add(cursor.getString(1));
                weightList.add(cursor.getString(2));
            }
        }
    }
}